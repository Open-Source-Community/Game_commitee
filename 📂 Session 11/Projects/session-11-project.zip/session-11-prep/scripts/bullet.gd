extends Area2D

@export var speed := 100.0
@export var damage := 15
var direction := Vector2.RIGHT

@onready var animation_player := $AnimationPlayer

func shoot(target_direction: Vector2):
	direction = target_direction.normalized()
	rotation = direction.angle()
	
	animation_player.play("shoot")
	#print("playing arrow shoot")

func _physics_process(delta):
	position += direction * speed * delta

# Free arrow when off-screen
func _on_visible_on_screen_notifier_screen_exited():
	queue_free()

# Handle collisions
func _on_body_entered(_body):
	#if body.is_in_group("enemy"):
		#body.take_damage(damage)
	#print("queue the arrow")
	#queue_free()
	pass
