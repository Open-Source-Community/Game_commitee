extends CharacterBody2D

## References
@onready var animation = $AnimatedSprite2D

## gravity variables
var gravity = 4000
var glide_gravity = 400
var current_gravity = gravity

## States list
enum States {IDLE, RUN, JUMP, FALL, GLIDE, ATTACK}

## variables
var current_state: States = States.IDLE

func _physics_process(delta):
	## gravity
	velocity += gravity * delta
	
	## why souldn't we use this method
	# check if jumping
	var is_jumping = is_on_floor() and Input.is_action_just_pressed("jump")
	if is_jumping:
		current_state = States.JUMP
	# check on falling
	elif current_state == States.JUMP and velocity.y > 0.0:
		current_state = States.FALL
	# check on gliding
	elif current_state in [States.FALL, States.JUMP] and Input.is_action_just_pressed("glide"):
		current_state = States.GLIDE
	
	## why sould we use state machine method

func set_state(new_state: int):
	var prev_state := current_state
	current_state = new_state
	
	# check on current and previous states
	if prev_state == States.GLIDE:
		current_gravity = gravity
	elif current_state == States.GLIDE:
		current_gravity = glide_gravity
	
	# check on current state to play it
	if current_state == States.IDLE:
		animation.play("idle")
	elif current_state == States.RUN:
		animation.play("run")
	# ......
	
	## all of this with implementing the FSM with one variable (current state)
	## now let's make it with Nodes and with class that have 5 functions
	
