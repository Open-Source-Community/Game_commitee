extends CharacterBody2D


const SPEED = 300.0
const JUMP_VELOCITY = -400.0

@onready var animation_player = $"AnimationPlayer"

@export var bullet = preload("res://scenes/bullet.tscn")
@export var fire_position: Node2D

var is_shooting = false

func _physics_process(delta):
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Handle jump.
	if Input.is_action_just_pressed("jump") and is_on_floor() and not is_shooting:
		animation_player.play("jump")
		velocity.y = JUMP_VELOCITY

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var direction = Input.get_axis("left", "right")
	if direction == 1:
		$AnimatedSprite2D.flip_h = false
	if direction == -1:
		$AnimatedSprite2D.flip_h = true

	if direction and not is_shooting:
		velocity.x = direction * SPEED
		animation_player.play("walk")
		#print("playing walk animation")
	else:
		if not is_shooting:
			velocity.x = move_toward(velocity.x, 0, SPEED)
			animation_player.play("idle")
			#print("playing idle animation")
		
	if Input.is_action_just_pressed("shoot"):
		is_shooting = true
		animation_player.play("shoot")
		print("plyaing player shoot")
		var child = bullet.instantiate()
		get_parent().add_child(child)
		child.global_position = fire_position.global_position
		child.shoot((get_global_mouse_position() - global_position).normalized())

	move_and_slide()

func _on_animation_player_animation_finished(anim_name):
	if anim_name == "shoot":
		is_shooting = false
		#print("shoot is false")
