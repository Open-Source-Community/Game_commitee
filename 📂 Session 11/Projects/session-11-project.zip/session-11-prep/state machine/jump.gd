class_name JumpState extends State

@export var fall_state: State

func enter():
	print("enter state jump")
	player.velocity.y = -player.jump_velocity  # Negative because in 2D, up is negative Y
	player.animation.play("jump")

func physics_update(delta):
	var input_dir = Input.get_axis("left", "right")
	player.velocity.x = input_dir * player.air_speed
	
	if player.velocity.y >= 0:  # Falling now
		state_machine.change_state(fall_state.name)
