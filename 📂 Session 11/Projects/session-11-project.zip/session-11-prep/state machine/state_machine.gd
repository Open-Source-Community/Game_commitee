class_name StateMachine extends Node

@export var initial_state: State
var current_state: State
var states: Dictionary = {}

func _ready():
	for child in get_children():
		if child is State:
			states[child.name.to_lower()] = child
			child.state_machine = self
			child.player = get_parent()
		
	if initial_state:
		initial_state.enter()
		current_state = initial_state

func change_state(new_state_name: String):
	var new_state = states.get(new_state_name.to_lower())
	if new_state:
		current_state.exit()
		new_state.enter()
		current_state = new_state

func _process(delta):
	if current_state:
		current_state.update(delta)

func _physics_process(delta):
	if current_state:
		current_state.physics_update(delta)

func _unhandled_input(event):
	if current_state:
		current_state.handle_input(event)
