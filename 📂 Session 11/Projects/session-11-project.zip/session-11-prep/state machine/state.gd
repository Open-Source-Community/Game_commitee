## virtual base class for all states
class_name State extends Node

var state_machine: StateMachine
var player: CharacterBody2D

## Called by the state machine when receiving unhandled input events.
func handle_input(_event: InputEvent) -> void:
	#print("handle_input function")
	pass

## Called by the state machine on the engine's main loop tick.
func update(_delta: float) -> void:
	#print("update function")
	pass

## Called by the state machine on the engine's physics update tick.
func physics_update(_delta: float) -> void:
	#print("physics_update function")
	pass

## Called by the state machine upon changing the active state. The 'data' parameter
## is a dictionary with arbitary data the state can use to inititate itsel.
func enter() -> void:
	#print("enter function")
	pass

## Called by the state machine before changing the active state. Use this function
## to clean up the state.
func exit() -> void:
	#print("exit function")
	pass
