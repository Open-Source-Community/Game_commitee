class_name FallState extends State

@export var idle_state: State
@export var run_state: State

func enter():
	print("enter state fall")
	player.animation.play("fall")

func physics_update(delta):
	var input_dir = Input.get_axis("left", "right")
	player.velocity.x = input_dir * player.air_speed
	
	if player.is_on_floor():
		if abs(input_dir) > 0.1:  # Small deadzone
			state_machine.change_state(run_state.name)
		else:
			state_machine.change_state(idle_state.name)
