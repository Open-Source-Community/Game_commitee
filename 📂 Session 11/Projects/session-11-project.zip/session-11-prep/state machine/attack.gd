class_name AttackState extends State

@export var idle_state: State
@export var run_state: State
@export var attack_cooldown: float = 0.3

var can_transition = false

func enter():
	print("enter state attack")
	player.animation.play("attack")
	player.velocity.x = 0
	can_transition = false
	
	# Simple one-shot connection without worrying about animation name
	player.animation.animation_finished.connect(
		func(): 
			can_transition = true
			state_machine.change_state(idle_state.name),  # Default to idle after attack
		CONNECT_ONE_SHOT
	)

func handle_input(event: InputEvent):
	if event.is_action_pressed("shoot") and can_transition:
		# Allow attacking again if cooldown is over
		state_machine.change_state("AttackState")

func physics_update(delta):
	# Apply gravity if in air
	if not player.is_on_floor():
		player.velocity.y += player.gravity * delta
