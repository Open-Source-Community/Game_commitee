extends CharacterBody2D

@export var speed := 300.0
@export var air_speed := 200.0
@export var jump_velocity := 400.0
@export var gravity := 980.0
@export var animation: AnimatedSprite2D
@export var state_machine: StateMachine


func _physics_process(delta):
	# Add gravity
	if not is_on_floor():
		velocity.y += gravity * delta
	
	move_and_slide()
