class_name RunState extends State

@export var idle_state: State
@export var jump_state: State
@export var fall_state: State
@export var attack_state: State

func enter():
	print("enter state run")
	player.animation.play("run")

func physics_update(delta):
	var input_dir = Input.get_axis("left", "right")
	
	# Flip sprite based on movement direction
	if input_dir != 0:
		player.animation.flip_h = input_dir < 0
	
	player.velocity.x = input_dir * player.speed
	
	if not player.is_on_floor():
		state_machine.change_state(fall_state.name)

func handle_input(event: InputEvent):
	if event.is_action_pressed("jump") and player.is_on_floor():
		state_machine.change_state(jump_state.name)
	
	if event.is_action("shoot"):
		state_machine.change_state(attack_state.name)
	
	var input_dir = Input.get_axis("left", "right")
	if abs(input_dir) < 0.1:  # Small deadzone
		state_machine.change_state(idle_state.name)
