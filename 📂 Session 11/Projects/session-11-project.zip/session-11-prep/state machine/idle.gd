class_name IdleState extends State

@export var run_state: State
@export var jump_state: State
@export var attack_state: State

func enter():
	print("enter state idle")
	player.animation.play("idle")
	player.animation.flip_h = false  # Reset facing direction

func physics_update(delta):
	# Apply small amount of friction even in idle state
	if player.is_on_floor():
		player.velocity.x = 0

func handle_input(event: InputEvent):
	if event.is_action_pressed("jump") and player.is_on_floor():
		state_machine.change_state(jump_state.name)
	
	if event.is_action_pressed("shoot"):
		state_machine.change_state(attack_state.name)
	
	var input_dir = Input.get_axis("left", "right")
	if abs(input_dir) > 0.1:  # Small deadzone
		state_machine.change_state(run_state.name)
	
